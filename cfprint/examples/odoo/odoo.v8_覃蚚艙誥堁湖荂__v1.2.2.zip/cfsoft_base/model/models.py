# -*- coding: utf-8 -*-

from openerp import models, fields, api

# class cfsoft_base(models.Model):
#     _name = 'cfsoft_base.cfsoft_base'

#     name = fields.Char()