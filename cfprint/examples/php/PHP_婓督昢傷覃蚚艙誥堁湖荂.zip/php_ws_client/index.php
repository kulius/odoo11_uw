<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>康虎云报表-PHP服务端调用测试</title>
</head>	
<body>


<div style="width: 100%;text-align:center;">
    <h2>康虎云报表系统（Ver 1.2.6.2）</h2>
    <h3>打印测试（通过PHP在服务端调用打印）</h3>
    <div>
        <a href='index.php?act=print'>发送打印</a>
    </div>
</div>
<div>

<?php
require_once ('lib/Base.php');
require_once ('lib/Client.php');
require_once ('lib/Exception.php');
require_once ('lib/BadUriException.php');
require_once ('lib/ConnectionException.php');

use WebSocket\Client;

$_srvPort = 54321;              //康虎云报表服务器监听端口，默认是：： 54321
$_srvAddress = 'localhost';     //康虎云报表服务器地址
$_srvProtocol = 'ws';           //康虎云报表通讯协议，目前暂不支持wss

if(isset($_REQUEST['act'])) {
    $act = $_REQUEST['act'];

    if (isset($act) && $act == 'print') {

    //定义打印数据，为了简便起见，这里把业务数据写死，实际使用中应根据业务对象生成json
        $_data=<<<MYJSON
{
    "template": "JD12P15V4.fr3", 
    "ver": 3, 
    "Tables": [
        {
            "Name": "Table1", 
            "Cols": [
                {"type": "str", "size": 255, "name": "序列号#","required": false}, 
                {"type": "str", "size": 255, "name": "ug_sn", "required": false},
                {"type": "str", "size": 255, "name": "ug_mac", "required": false}, 
                {"type": "str", "size": 255, "name": "ug_code", "required": false}
            ], 
            "Data": [
                {
                    "ug_hardware": "JD12P15", 
                    "ug_ver": "4", 
                    "ug_week": "9", 
                    "ug_index": "54510", 
                    "ug_mac": "F0-FF-04-00-D4-EE", 
                    "ug_sn": "JD12P15V4 1709001", 
                    "ug_code": "UG0400-12F275-06E629-05E420-0DF401", 
                    "ug_createtime": "2017-03-03 16:12:01", 
                    "ug_isprinted": "0"
                }, 
                {
                    "ug_hardware": "JD12P15", 
                    "ug_ver": "4", 
                    "ug_week": "9", 
                    "ug_index": "54511", 
                    "ug_mac": "F0-FF-04-00-D4-EF", 
                    "ug_sn": "JD12P15V4 1709002", 
                    "ug_code": "UG0400-15A165-0BACE9-0E5520-0A1052", 
                    "ug_createtime": "2017-03-03 16:12:01", 
                    "ug_isprinted": "0"
                }, 
                {
                    "ug_hardware": "JD12P15", 
                    "ug_ver": "4", 
                    "ug_week": "9", 
                    "ug_index": "54512", 
                    "ug_mac": "F0-FF-04-00-D4-F0", 
                    "ug_sn": "JD12P15V4 1709003", 
                    "ug_code": "UG0400-1F7205-0873E9-09D9A0-0A2663", 
                    "ug_createtime": "2017-03-03 16:12:01", 
                    "ug_isprinted": "0"
                }, 
                {
                    "ug_hardware": "JD12P15", 
                    "ug_ver": "4", 
                    "ug_week": "9", 
                    "ug_index": "54513", 
                    "ug_mac": "F0-FF-04-00-D4-F1", 
                    "ug_sn": "JD12P15V4 1709004", 
                    "ug_code": "UG0400-121975-0390F9-0A90E0-0D0B04", 
                    "ug_createtime": "2017-03-03 16:12:01", 
                    "ug_isprinted": "0"
                }, 
                {
                    "ug_hardware": "JD12P15", 
                    "ug_ver": "4", 
                    "ug_week": "9", 
                    "ug_index": "54514", 
                    "ug_mac": "F0-FF-04-00-D4-F2", 
                    "ug_sn": "JD12P15V4 1709005", 
                    "ug_code": "UG0400-1AA125-0EBFE9-040700-00FD95", 
                    "ug_createtime": "2017-03-03 16:12:01", 
                    "ug_isprinted": "0"
                }
            ]
        }
    ]
}
MYJSON;


echo "<pre>";
echo "本次发送的打印数据如下：<br/>";
echo "================================<br/>";
echo $_data;
echo "</pre>";


        $_url = $_srvProtocol . "://" . $_srvAddress . ":" . $_srvPort;     //拼接成完整的
        $client = new Client($_url);

        $client->send($_data);

        $resp = $client->receive();

        echo "本次打印结果：<br/>";
        echo $resp;
    } else{
        echo '未知指令。';
    }
}
?>
</div>
</body>
</html>